module.exports = {
  content: [`./views/**/*.html`], // all .html files
  // ...
};
